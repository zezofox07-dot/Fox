package com.novalive.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RoomActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_room)

        // Simulate an entering user (in real app this would be triggered by RTC event)
        val enteringUserName = intent.getStringExtra("enteringName") ?: "ضيف جديد"

        val overlay = findViewById<View>(R.id.entranceOverlay)
        val nameTv = findViewById<TextView>(R.id.entranceName)
        val badgeTv = findViewById<TextView>(R.id.entranceBadge)

        nameTv.text = enteringUserName
        // show badge for demo (could depend on user status)
        badgeTv.visibility = View.VISIBLE
        badgeTv.text = "VIP"

        // Play entrance animation
        val animIn = AnimationUtils.loadAnimation(this, R.anim.fade_scale_in)
        overlay.visibility = View.VISIBLE
        overlay.startAnimation(animIn)

        // hide after 2.5 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            val animOut = AnimationUtils.loadAnimation(this, R.anim.fade_out)
            overlay.startAnimation(animOut)
            overlay.visibility = View.GONE
        }, 2500)
    }
}
