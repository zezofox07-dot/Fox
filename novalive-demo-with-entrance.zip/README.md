# NovaLive Demo (Minimal scaffold)

This is a minimal Android project scaffold for **NovaLive** (demo). It is set up so that:

- You can clone this repo, add your `google-services.json` (Firebase) and ZEGOCLOUD/Agora keys in `app/keystore.properties` or `app/src/main/res/values/strings.xml`, then build locally with Android Studio.
- Or push to GitHub and GitHub Actions will build an APK automatically (after you add secrets and the google-services.json).

## What I included
- Minimal Android app (Kotlin) with placeholder UI and sample RoomActivity.
- `github/workflows/android-build.yml` - GitHub Actions workflow to build the APK.
- `app/build.gradle` and root Gradle files configured for a simple build.
- An SVG placeholder logo `novalive_logo.svg`.

## How to use (quick)
1. Add `google-services.json` to `app/` (for Firebase). For demo/testing you can use Firebase test phone numbers.
2. Open project in Android Studio and build/run, or push to GitHub.
3. If using GitHub Actions, add repository secret `ANDROID_KEYSTORE_BASE64` (optional) and any API keys as secrets (e.g., ZEGOCLOUD_APPID).

## GitHub Actions
The workflow will:
- Set up Java/Android SDK
- Build the APK using Gradle
- Upload an artifact `app-release.apk` for download

⚠️ This scaffold uses placeholder SDK entries. Replace the RTC SDK dependency and config with your provider (ZEGOCLOUD/Agora) when ready.


## Entrance Animation Demo

The RoomActivity now includes a simple entrance overlay animation (fade+scale) that displays a user's name and badge when they join the room. This is a UI-only demo and can be triggered by passing an extra `enteringName` in the intent.
